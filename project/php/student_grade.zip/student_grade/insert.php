<?php
    include_once "dbconnect.php";


    $name = $_POST['name'];
    $m1 = $_POST['m1'];
    $m2 = $_POST['m2'];
    $m3 = $_POST['m3'];
    $m4 = $_POST['m4'];
    $tot=$m1+$m2+$m3+$m4;
    if($tot>=150)
        $gra='A';
    elseif($tot>=130 && $tot<=149)
        $gra='B';
    elseif($tot>=120 && $tot<=129)
        $gra='c';
    elseif($tot>=110 && $tot<=119)
        $gra='D';
    else
        $gra='F';




    $query = "INSERT INTO `insert_db` (`name`, `m1`, `m2`, `m3`, `m4`,`tot`,`gra`) VALUES ('$name', '$m1', '$m2', '$m3', '$m4', '$tot','$gra')";

    
        //execute query
        $result = $con->query($query);
        //display result
        if ($result){
            header("Location:display.php");
        }
        else{
            echo "error";
        }
  

?>




