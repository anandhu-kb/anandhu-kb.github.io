<?php
    include_once "dbconnect.php";

    $name = $_POST['name'];
    $number = $_POST['number'];


    $query1 = "INSERT INTO `db` (`name`, `number`) VALUES ('$name', '$number')";

    //checking data is inserted or not
    $query2="SELECT * FROM `db` WHERE name='$name'";
    
    $result1=$con->query($query2);

    $row = mysqli_fetch_assoc($result1);

    if($row)
    {
        echo '<script> alert("name exists");window.location.href = "index.html";</script>';
 
    }
    else
    {
        //execute query
        $result = $con->query($query1);
        //display result
        if ($result)
        {
            header("Location:display.php");
        }
        else
        {
            echo "error";
        }
    }
?>
