<?php
        include "dbconnect.php";
        $query = "SELECT * FROM `db`";
        $result=$con->query($query);

        if ($result) {
            echo "<h2>Results:</h2>";
            echo "<table border='1'>";
            echo "<tr><th>Name</th><th>Number</th></tr>";
    
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["number"] . "</td>";
                echo "</tr>";
            }

        }
    
            echo "</table>";


            echo '<a href="index.html">Index</a>';

?>