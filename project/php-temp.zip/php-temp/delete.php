
<?php
                include "dbconnect.php";

                $num=$_POST['num'];
                $query="DELETE FROM `insert_db` WHERE number='$num'";
                $result = mysqli_query($con,$query);
                if($result){
                    echo "deleted";
                    header("Location:display.php");
                }
                else{
                        echo "error";


            }


        ?>