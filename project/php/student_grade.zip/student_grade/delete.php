
<?php
                include "dbconnect.php";

                $query="DELETE FROM `insert_db`";
                $result = mysqli_query($con,$query);
                if($result){
                    echo "deleted";
                    header("Location:display.php");
                }
                else{
                        echo "error";


            }


        ?>