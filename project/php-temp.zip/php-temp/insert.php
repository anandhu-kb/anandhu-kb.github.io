<?php
    include_once "dbconnect.php";


    $name = $_POST['name'];
    $number = $_POST['number'];


    $query1 = "INSERT INTO `insert_db` (`name`, `number`) VALUES ('$name', '$number')";

    //checking data is inserted or not
    $query2='SELECT name FROM `insert_db` WHERE name="$name"';
    $query3='SELECT number FROM `insert_db` WHERE number="$number"';

    $result1=$con->query($query2);
    $result2=$con->query($query3);
    if($result1){
        if($result2){
        echo '<script> alert("name and number exists");window.location.href = "index.html";</script>';

        }
        else{
            echo '<script> alert("name exists");window.location.href = "index.html";</script>';

        }
    }
    else{
        
        //execute query
        $result = $con->query($query1);
        //display result
        if ($result){
            header("Location:display.php");
        }
        else{
            echo "error";
        }
    }    

?>




