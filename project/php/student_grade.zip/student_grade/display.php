<?php
        include "dbconnect.php";
        $query = "SELECT * FROM `insert_db`";
        $result=$con->query($query);

        if ($result) {
            echo "<h2>Results:</h2>";
            echo "<table border='1'>";
            echo "<tr><th>Name</th><th>Mark1</th><th>Mark2</th><th>Mark3</th><th>Mark4</th><th>Total</th><th>Grade</th></tr>";
    
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["m1"] . "</td>";
                echo "<td>" . $row["m2"] . "</td>";
                echo "<td>" . $row["m3"] . "</td>";
                echo "<td>" . $row["m4"] . "</td>";
                echo "<td>" . $row["tot"] . "</td>";
                echo "<td>" . $row["gra"] . "</td>";

                echo "</tr>";
            }

        }
    
            echo "</table>";


            echo '<a href="index.html">Index</a>';

?>